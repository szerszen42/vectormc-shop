@echo off
chcp 65001 >nul
title Zamykanie VectorMc
cd /d "%~dp0"
echo ========================================================
echo  Zatrzymywanie wszystkich procesow VectorMc...
echo ========================================================
taskkill /F /IM VectorMc.exe /T >nul 2>&1
taskkill /F /IM vectormc-rust.exe /T >nul 2>&1

:: Zwalnianie portu 3000 jesli jakis proces w tle go trzyma
for /f "tokens=5" %%p in ('netstat -aon ^| findstr ":3000" 2^>nul') do (
  if not "%%p"=="" (
    taskkill /F /PID %%p >nul 2>&1
  )
)
timeout /t 1 /nobreak >nul
echo.
echo [OK] Wszystkie boty i procesy VectorMc zostaly pomyslnie wylaczone.
echo ========================================================
timeout /t 2 >nul
