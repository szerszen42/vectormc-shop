@echo off
title VectorMc Rust Edition - Uruchamianie
cd /d "%~dp0"

set "RUST_TOOLCHAIN=%USERPROFILE%\.rustup\toolchains\stable-x86_64-pc-windows-gnu"
if exist "%RUST_TOOLCHAIN%\lib\rustlib\x86_64-pc-windows-gnu\bin\self-contained\dlltool.exe" (
  set "PATH=%RUST_TOOLCHAIN%\lib\rustlib\x86_64-pc-windows-gnu\bin\self-contained;%RUST_TOOLCHAIN%\lib\rustlib\x86_64-pc-windows-gnu\bin;%RUST_TOOLCHAIN%\bin;%PATH%"
) else (
  for /d %%T in (%USERPROFILE%\.rustup\toolchains\*) do (
    if exist "%%~T\lib\rustlib\x86_64-pc-windows-gnu\bin\self-contained\dlltool.exe" (
      set "PATH=%%~T\lib\rustlib\x86_64-pc-windows-gnu\bin\self-contained;%%~T\lib\rustlib\x86_64-pc-windows-gnu\bin;%%~T\bin;%%PATH%"
    )
  )
)

if exist VectorMc.exe (
  start "" VectorMc.exe
  exit
) else (
  echo Uruchamianie bezposrednio przez Cargo (Rust)...
  cargo run --release
)
