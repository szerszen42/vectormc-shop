@echo off
title Tworzenie skrotu na Pulpicie
echo Tworzenie skrotu do VectorMc na Twoim Pulpicie...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([System.Environment]::GetFolderPath('Desktop'), 'VectorMc.lnk')); $s.TargetPath = [System.IO.Path]::Combine('%~dp0', 'VectorMc.exe'); $s.WorkingDirectory = '%~dp0'; $s.Save()"
echo.
echo ==============================================
echo [OK] Skrot VectorMc zostal utworzony na Pulpicie!
echo Mozesz teraz uruchamiac bota prosto z Pulpitu.
echo ==============================================
timeout /t 3 >nul
